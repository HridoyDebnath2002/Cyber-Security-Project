function hashSHA512() {
    const plaintext = document.getElementById("hash-plaintext").value;
    const password = document.getElementById("hash-password").value;

    if (plaintext && password) {
        // Combine plaintext with the password
        const combinedInput = `${plaintext}${password}`;
        
        // Generate the SHA-512 hash
        const hash = CryptoJS.SHA512(combinedInput).toString();
        
        // Display the result
        document.getElementById("hash-result").value = `Hash: ${hash}`;
    } else {
        alert("Please provide both plaintext and password for SHA-512 hashing.");
    }
}
