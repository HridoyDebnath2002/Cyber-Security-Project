function encryptAES() {
    const plaintext = document.getElementById("aes-plaintext").value;
    const p = parseInt(document.getElementById("aes-p").value);
    const q = parseInt(document.getElementById("aes-q").value);

    if (plaintext && p && q) {
        const n = p * q;
        const ciphertext = CryptoJS.AES.encrypt(plaintext, n.toString()).toString();
        document.getElementById("aes-result").value = `Ciphertext: ${ciphertext}\nKey (N): ${n}`;
    } else {
        alert("Please provide plaintext and both prime numbers.");
    }
}

function decryptAES() {
    const ciphertext = document.getElementById("aes-plaintext").value;
    const p = parseInt(document.getElementById("aes-p").value);
    const q = parseInt(document.getElementById("aes-q").value);

    if (ciphertext && p && q) {
        const n = p * q;
        const bytes = CryptoJS.AES.decrypt(ciphertext, n.toString());
        const decryptedText = bytes.toString(CryptoJS.enc.Utf8);
        document.getElementById("aes-result").value = `Decrypted Text: ${decryptedText}`;
    } else {
        alert("Please provide ciphertext and both prime numbers.");
    }
}
