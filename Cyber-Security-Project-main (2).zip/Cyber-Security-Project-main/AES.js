function encryptAES() {
    const plaintext = document.getElementById("aes-plaintext").value;
    const p = parseInt(document.getElementById("aes-p").value);
    const q = parseInt(document.getElementById("aes-q").value);

    if (plaintext && p && q) {
        const n = p * q; // Public Key N = P * Q
        const ciphertext = CryptoJS.AES.encrypt(plaintext, n.toString()).toString();
        
        // Display the public key (N) and ciphertext
        document.getElementById("aes-public-key").value = n;
        document.getElementById("aes-result").value = ciphertext;
    } else {
        alert("Please provide plaintext and both prime numbers (P and Q).");
    }
}

function decryptAES() {
    const ciphertext = document.getElementById("aes-ciphertext").value;
    const p = parseInt(document.getElementById("aes-p").value);
    const q = parseInt(document.getElementById("aes-q").value);

    if (ciphertext && p && q) {
        const n = p * q; // Public Key N = P * Q
        try {
            const bytes = CryptoJS.AES.decrypt(ciphertext, n.toString());
            const decryptedText = bytes.toString(CryptoJS.enc.Utf8);

            if (decryptedText) {
                document.getElementById("aes-decrypted-result").value = decryptedText;
            } else {
                alert("Decryption failed. Check your ciphertext and keys.");
            }
        } catch (error) {
            alert("Decryption error: " + error.message);
        }
    } else {
        alert("Please provide ciphertext and both prime numbers (P and Q).");
    }
}
