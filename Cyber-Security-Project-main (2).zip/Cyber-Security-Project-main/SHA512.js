function hashSHA512() {
    const plaintext = document.getElementById("hash-plaintext").value;
    const password = document.getElementById("hash-password").value;

    if (plaintext && password) {
        const combinedInput = `${plaintext}${password}`;
        const hash = CryptoJS.SHA512(combinedInput).toString();
        document.getElementById("hash-result").value = `Hash: ${hash}`;
    } else {
        alert("Please provide both plaintext and password.");
    }
}
