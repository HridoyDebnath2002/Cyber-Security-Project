function encrypt() {
    const plaintext = document.getElementById("plaintext").value.toUpperCase().replace(/\s/g, "");
    const rails = parseInt(document.getElementById("rails").value);
    const key = document.getElementById("key").value.trim().split(" ").map(Number);
    const algorithm = document.getElementById("algorithm").value;
    let ciphertext = "";

    if (algorithm === "railfence") {
        if (!rails || rails < 2) {
            alert("Please provide a valid number of rails (minimum 2).");
            return;
        }

        // Create the rail matrix
        const railArray = Array.from({ length: rails }, () => []);

        let rail = 0;
        let direction = 1;

        // Distribute characters across rails
        for (let i = 0; i < plaintext.length; i++) {
            railArray[rail].push(plaintext[i]);
            rail += direction;
            if (rail === 0 || rail === rails - 1) direction *= -1;
        }

        // Concatenate the rails to form the ciphertext
        ciphertext = railArray.flat().join("");
    } else if (algorithm === "rowcipher") {
        if (!key || key.length === 0) {
            alert("Please provide a valid key for Row Transposition Cipher.");
            return;
        }

        const columns = key.length;

        // Pad plaintext to fit the matrix
        const padding = columns - (plaintext.length % columns);
        const paddedPlaintext = plaintext + "X".repeat(padding);

        // Create the plaintext matrix
        const rows = Math.ceil(paddedPlaintext.length / columns);
        const matrix = [];
        for (let i = 0; i < rows; i++) {
            matrix.push(paddedPlaintext.slice(i * columns, (i + 1) * columns).split(""));
        }

        // Transpose the matrix based on the key
        const transposedMatrix = Array.from({ length: rows }, () => []);
        for (let i = 0; i < columns; i++) {
            const colIndex = key.indexOf(i + 1); // Key determines the column order
            for (let j = 0; j < rows; j++) {
                transposedMatrix[j][i] = matrix[j][colIndex];
            }
        }

        // Concatenate the transposed columns to form the ciphertext
        ciphertext = transposedMatrix.flat().join("");
    }

    document.getElementById("ciphertext").value = ciphertext;
}

function decrypt() {
    const ciphertext = document.getElementById("ciphertext").value.toUpperCase().replace(/\s/g, "");
    const rails = parseInt(document.getElementById("rails").value);
    const key = document.getElementById("key").value.trim().split(" ").map(Number);
    const algorithm = document.getElementById("algorithm").value;
    let decryptedText = "";

    if (algorithm === "railfence") {
        if (!rails || rails < 2) {
            alert("Please provide a valid number of rails (minimum 2).");
            return;
        }

        // Create the rail matrix
        const railArray = Array.from({ length: rails }, () => []);
        const charPositions = [];

        let rail = 0;
        let direction = 1;

        // Mark character positions
        for (let i = 0; i < ciphertext.length; i++) {
            railArray[rail].push(null);
            charPositions.push([rail, railArray[rail].length - 1]);
            rail += direction;
            if (rail === 0 || rail === rails - 1) direction *= -1;
        }

        // Fill the rail matrix with ciphertext characters
        let charIndex = 0;
        for (let r = 0; r < rails; r++) {
            for (let c = 0; c < railArray[r].length; c++) {
                railArray[r][c] = ciphertext[charIndex++];
            }
        }

        // Read characters back in zigzag order
        for (let [rail, col] of charPositions) {
            decryptedText += railArray[rail][col];
        }
    } else if (algorithm === "rowcipher") {
        if (!key || key.length === 0) {
            alert("Please provide a valid key for Row Transposition Cipher.");
            return;
        }

        const columns = key.length;
        const rows = Math.ceil(ciphertext.length / columns);

        // Create the transposed ciphertext matrix
        const transposedMatrix = [];
        let charIndex = 0;
        for (let i = 0; i < rows; i++) {
            transposedMatrix.push([]);
            for (let j = 0; j < columns; j++) {
                transposedMatrix[i][j] = ciphertext[charIndex++];
            }
        }

        // Transpose back to the original order based on the key
        const originalMatrix = Array.from({ length: rows }, () => []);
        for (let i = 0; i < columns; i++) {
            const colIndex = key.indexOf(i + 1);
            for (let j = 0; j < rows; j++) {
                originalMatrix[j][colIndex] = transposedMatrix[j][i];
            }
        }

        // Concatenate the original rows to form the decrypted text
        decryptedText = originalMatrix.flat().join("").replace(/X+$/, ""); // Remove padding
    }

    document.getElementById("decryptedtext").value = decryptedText;
}
